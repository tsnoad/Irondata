<?php
// $Header: /cvsroot/html2ps/tag.utils.inc.php,v 1.3 2005/07/01 18:01:58 Konstantin Exp $
?>